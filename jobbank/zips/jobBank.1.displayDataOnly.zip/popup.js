// Get the current tab
browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
  // Inject the script into the current tab
  browser.tabs.executeScript(tabs[0].id, {file: "content.js"});
});

// Listen for messages from the content script
browser.runtime.onMessage.addListener(function(message) {
  // Display the details in the popup
  document.getElementById('details').innerText = message;
});

// Add a click event listener to the copy button
document.getElementById('copyButton').addEventListener('click', function() {
  // Create a new textarea element and set its value to the details
  var textarea = document.createElement('textarea');
  textarea.value = document.getElementById('details').innerText;
  document.body.appendChild(textarea);

  // Select the textarea's content and copy it to the clipboard
  textarea.select();
  document.execCommand('copy');

  // Remove the textarea element
  document.body.removeChild(textarea);

  // Display a message indicating that the details have been copied
  document.getElementById('message').innerText = 'Copied!';
});