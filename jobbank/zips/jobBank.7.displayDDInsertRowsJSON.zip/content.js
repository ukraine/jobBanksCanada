// Check if the "Show how to apply" button is present
var applyButton = document.querySelector('#applynowbutton');
if (applyButton) {
  // Click the button
  
  applyButton.click();
}

setTimeout(function() {

function extractPropertyContent(propertyName) {
   const element = document.querySelector(`[property="${propertyName}"]`);
   return element !== null ? element.innerText.trim() : "0";
 }

const keysToExtractForuOutput = [
      "status", 
      "datePosted", "dateSaved", "validThrough", "jobId", 
      "title", "companyName", "website", "email", "verified",
      "minValue", "maxValue", "workHours", "referenceNumber",
      "addressRegion", "addressLocality", "streetAddress", "postalCode", 
      "specialInstructions",
      "industry", "cms", "yearSiteUpdated", "aboutUrl", "portfolioUrl","contactUrl", "programmingServer", "source",
   ];

    // Initialize all variables to "0"
    const extractedData = {};
    keysToExtractForuOutput.forEach(variableName => {
    extractedData[variableName] = "0";
});

 var keysToExtract = [
   "title",
   "minValue",
   "maxValue",
   "addressRegion",
   "addressLocality",
   "streetAddress",
   "postalCode",
   "datePosted",
   "validThrough",
   "workHours"
 ];

 
 keysToExtract.forEach(key => {
   if (key === "datePosted") {
     extractedData[key] = extractPropertyContent(key).replace("Posted on ", "") || "0";
   } else if (key === "validThrough") {
     extractedData[key] = extractPropertyContent(key).split(' ')[0];
   } else {
     extractedData[key] = extractPropertyContent(key);
   }
 });

extractedData['status'] = "new";
 
var emailElement = document.querySelector('h4#htaemail + p a');
extractedData["email"] = emailElement !== null ? emailElement.getAttribute('href').replace('mailto:', '') : "0";


var referenceNumberElement = document.querySelector('h4#htaemail + p + h4 + p');
extractedData["referenceNumber"] = referenceNumberElement !== null ? referenceNumberElement.innerText : "";

var includeReference = extractedData["referenceNumber"] !== null ? "<br>Include this reference number " : "";

var specialInstructionsElement = document.querySelector('h4#htaemail + p + h4 + p + h4 + p + ul + p + ul');
extractedData["specialInstructions"] = specialInstructionsElement !== null ? specialInstructionsElement.innerText.replace(/(?:\r\n|\r|\n)/g, '<br>') + includeReference + extractedData["referenceNumber"] : "0";

var companyNameElement1 = document.querySelector('span[property="hiringOrganization"] span[property="name"] a');
var companyNameElement2 = document.querySelector('span[property="hiringOrganization"] span[property="name"] strong');

extractedData["companyName"] = companyNameElement1 !== null ? companyNameElement1.innerText :
  (companyNameElement2 !== null ? companyNameElement2.innerText : "0");

// Normalize the company name and website
extractedData["companyName"] = extractedData["companyName"].toLowerCase().replace(/\b\w/g, l => l.toUpperCase());

extractedData["verified"] = document.querySelector('.verified.job-marker .text').innerText;

var websiteElement = document.querySelector('span[property="hiringOrganization"] a');
extractedData['website'] = websiteElement !== null ? websiteElement.getAttribute('href') : "0";


if (extractedData['website'] != "0") {
   extractedData['website'] = extractedData['website'].replace(/^(https?:\/\/)?(www\.)?/, ''); // Remove protocol and "www."
   extractedData['website'] = extractedData['website'].replace(/\/$/, '').toLowerCase(); // Remove trailing slash
   // website = website.;
}

if (extractedData["email"] && extractedData['website'] === "0") {
   var atIndex = extractedData["email"].indexOf('@');
   if (atIndex !== -1) {
      extractedData['website'] = extractedData["email"].substring(atIndex + 1);
     
     var commonDomains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "live.ca", "mail.com"];
     if (!commonDomains.includes(extractedData['website'])) {
       // Use the email domain as the website
       // website = websiteFromEmail;
     } else {
       // Reset websiteFromEmail to "0" for common domains
       extractedData['website'] = "0";
     }
   }
 }
 
// Split the title into separate parts

// Extract the job id from the URL
extractedData["jobId"] = document.querySelector('a[data-jobid]').getAttribute('data-jobid');
extractedData["dateSaved"] = new Date().toISOString().split('T')[0];

var urlObject = new URL(window.location.href);
extractedData['source'] = urlObject.hostname.replace(/^www\./, '').toLowerCase();

console.log(extractedData);

// Send the details to the popup
browser.runtime.sendMessage(JSON.stringify(extractedData));

}, 1500);