// Check if the "Show how to apply" button is present
var applyButton = document.querySelector('#applynowbutton');
if (applyButton) {
  // Click the button
  applyButton.click();
}

setTimeout(function() {
// Get the title, meta og:url, and additional data
var titleElement = document.querySelector('title');
var title = titleElement !== null ? titleElement.innerText : "0";

var metaOgUrlElement = document.querySelector('meta[property="og:url"]');
var metaOgUrl = metaOgUrlElement !== null ? metaOgUrlElement.getAttribute('content') : "0";

var minValueElement = document.querySelector('span[property="minValue"]');
var minValue = minValueElement !== null ? minValueElement.getAttribute('content') : "0";

var ApplyByElement = document.querySelector('p[property="validThrough"]');
var ApplyByDate = ApplyByElement !== null ? ApplyByElement.innerText.split(' ')[0] : "0";

var workHoursElement = document.querySelector('span[property="workHours"]');
var workHours = workHoursElement !== null ? workHoursElement.innerText.split(' ')[0] : "0";

var emailElement = document.querySelector('h4#htaemail + p a');
var email = emailElement !== null ? emailElement.getAttribute('href').replace('mailto:', '') : "0";

var jobBankIdElement = document.querySelector('li span:nth-child(4)');
var jobBankId = jobBankIdElement !== null ? jobBankIdElement.innerText : null;

var streetAddressElement = document.querySelector('span[property="streetAddress"]');
var streetAddress = streetAddressElement !== null ? streetAddressElement.innerText : "0";

var postalCodeElement = document.querySelector('span[property="postalCode"]');
var postalCode = postalCodeElement !== null ? postalCodeElement.innerText : "0";;

var companyNameElement1 = document.querySelector('span[property="hiringOrganization"] span[property="name"] a');
var companyNameElement2 = document.querySelector('span[property="hiringOrganization"] span[property="name"] strong');

var companyName = null;

if (companyNameElement1 !== null) {
    companyName = companyNameElement1.innerText;
} else if (companyNameElement2 !== null) {
    companyName = companyNameElement2.innerText;
}

// If companyName is still null, set it to "0"
if (companyName === null) {
    companyName = "0";
}

var websiteElement = document.querySelector('span[property="hiringOrganization"] a');
var website = websiteElement !== null ? websiteElement.getAttribute('href') : "0";

var verifiedElement = document.querySelector('.verified.job-marker .text');
var verified = verifiedElement !== null ? "1" : "0";

var maxValueElement = document.querySelector('span[property="maxValue"]');
var maxValue = maxValueElement !== null ? maxValueElement.getAttribute('content') : "0";

// Normalize the company name and website
companyName = companyName.toLowerCase().replace(/\b\w/g, l => l.toUpperCase());
website = website.toLowerCase();

if (email && website == "0" ) {
    var atIndex = email.indexOf('@');
    if (atIndex !== -1) {
      website = email.substring(atIndex + 1);
        
        var commonDomains = ["gmail.com", "yahoo.com", "outlook.com"];
        if (commonDomains.includes(website)) {
         website = "0"; // Ignore common domains
        }
    }
}

// Split the title into separate parts
var titleParts = title.split(' - ');

// Further split the location into city and province
var locationParts = titleParts[1].split(', ');

// Extract the job id from the URL
var jobIdUrl = metaOgUrl.split('/').pop();

// var headings = `"ID", "Title", "companyName", "website", "Email", "MinRate", "MaxRate", "workHours", "City", "Province", "streetAddress", "postalCode"<br>`;

// Combine all parts into a single string
var output = `"${jobIdUrl}", "${jobBankId}", "${ApplyByDate}", "${titleParts[0]}", "${companyName}", "${website}", "${email}", "${minValue}", "${maxValue}", "${workHours}", "${locationParts[0]}", "${locationParts[1]}", "${streetAddress}", "${postalCode}"`;

// Send the details to the popup
browser.runtime.sendMessage(output);

}, 1500);
